package com.music.bitchord.data.aimix

import android.content.Context
import android.util.Log
import com.music.bitchord.data.YtMusicRepository
import com.music.bitchord.data.model.SearchFilter
import com.music.bitchord.data.model.SearchResult
import com.music.bitchord.data.model.Song
import com.music.bitchord.data.stats.ArtistFacts
import com.music.bitchord.data.stats.ListeningStats
import com.music.bitchord.data.stats.RankedSong
import com.music.bitchord.data.stats.ReplayPeriod
import com.music.bitchord.playback.smart.AiMixCandidate
import com.music.bitchord.playback.smart.AiMixEngine
import com.music.bitchord.playback.smart.AiMixFeatures
import com.music.bitchord.playback.smart.AiMixGenre
import com.music.bitchord.playback.smart.AiMixGenres
import com.music.bitchord.playback.smart.AiMixMode
import com.music.bitchord.playback.smart.AiMixOrigin
import com.music.bitchord.playback.smart.AiMixTaste
import com.music.bitchord.playback.smart.AnalysisStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlin.random.Random

/** A finished mix, ready to be queued. */
data class AiMixResult(
    val songs: List<Song>,
    /** What the queue is called, e.g. `AI Mix · Jazz`. */
    val title: String,
    /** The genre the mix was built around, or null for a mix built from habits. */
    val genre: AiMixGenre?,
)

/**
 * Builds AI Mixes: a queue made from what the listener plays, or from a genre,
 * either picked by hand or chosen at random.
 *
 * Everything the listener's history contributes stays on the device. The only
 * network traffic is what browsing YouTube Music already makes — a radio for a
 * few songs, or a few searches for the genre — and none of it carries the
 * history, only the ids and names of the songs being asked about.
 *
 * The ranking itself is in [AiMixEngine], which has no I/O; this gathers its
 * inputs.
 */
object AiMix {

    private const val TAG = "AiMix"

    /** How many top songs are considered as seeds, and how many of them are used per mix. */
    private const val SEED_POOL = 12
    private const val SEEDS_PER_MIX = 5
    private const val EXTRA_SEEDS = 2

    data class State(
        val busy: Boolean = false,
        /** The last attempt found nothing to play. Cleared by the next one. */
        val failed: Boolean = false,
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    @Volatile
    private var lastSurprise: String? = null

    @Volatile
    private var store: AnalysisStore? = null

    /**
     * Builds one mix, or returns null when nothing could be found (offline, or
     * nothing to seed from). Ignored while another is being built.
     */
    suspend fun build(context: Context, requested: AiMixMode): AiMixResult? {
        if (_state.value.busy) return null
        _state.value = State(busy = true)
        var failed = false
        try {
            val built = withContext(Dispatchers.IO) { buildInternal(context.applicationContext, requested) }
            failed = built == null
            return built
        } catch (failure: Exception) {
            // A cancelled build is the user leaving, not a failure to report.
            if (failure is CancellationException) throw failure
            Log.w(TAG, "AI Mix failed", failure)
            failed = true
            return null
        } finally {
            _state.value = State(busy = false, failed = failed)
        }
    }

    private suspend fun buildInternal(context: Context, requested: AiMixMode): AiMixResult? {
        val random = Random.Default
        val summary = ListeningStats.summary(ReplayPeriod.ALL_TIME)
        val taste = tasteFrom(summary.songs, summary.artists.map { it.title to it.ms })

        // "For you" with no history has nothing to be for; make it a surprise
        // rather than an empty queue.
        val mode = when {
            requested is AiMixMode.Surprise ||
                (requested is AiMixMode.ForYou && summary.isEmpty) -> {
                val picked = AiMixGenres.pickSurprise(random, except = lastSurprise)
                lastSurprise = picked.id
                AiMixMode.Genre(picked.id)
            }
            else -> requested
        }
        val genre = (mode as? AiMixMode.Genre)?.let { AiMixGenres.byId(it.id) }

        val candidates = when (mode) {
            is AiMixMode.Genre -> if (genre != null) genreCandidates(genre, summary.songs, taste, random) else emptyList()
            else -> habitCandidates(summary.songs, random)
        }
        if (candidates.isEmpty()) return null

        val tasteWithCandidates = withCandidateArtists(taste, candidates.map { it.song })
        val songs = AiMixEngine.build(
            mode = mode,
            taste = tasteWithCandidates,
            candidates = candidates,
            features = featuresFor(context, candidates.map { it.song.videoId }),
            random = random,
        )
        if (songs.isEmpty()) return null
        return AiMixResult(
            songs = songs,
            title = if (genre != null) "AI Mix · ${genre.label}" else "AI Mix",
            genre = genre,
        )
    }

    // ── Taste ────────────────────────────────────────────────────────────────

    private fun tasteFrom(songs: List<RankedSong>, artists: List<Pair<String, Long>>): AiMixTaste {
        val maxMs = artists.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: 1L
        val weights = HashMap<String, Double>()
        val genres = HashMap<String, Set<String>>()
        for ((name, ms) in artists) {
            val key = AiMixEngine.artistKey(name)
            weights[key] = ms.toDouble() / maxMs
            genresOf(name)?.let { genres[key] = it }
        }
        return AiMixTaste(
            songPlays = songs.associate { it.song.videoId to it.plays },
            artistWeights = weights,
            artistGenres = genres,
        )
    }

    /**
     * The history keys artists by their lead name, a candidate's byline names
     * everyone ("A & B"). Copy the lead's weight and genres onto the full
     * credit so a collaboration counts as its main artist, and add what is
     * already known about the candidates' own artists. Reads only; nothing here
     * asks the network about an artist.
     */
    private fun withCandidateArtists(taste: AiMixTaste, candidates: List<Song>): AiMixTaste {
        val weights = HashMap(taste.artistWeights)
        val genres = HashMap(taste.artistGenres)
        for (song in candidates) {
            val full = AiMixEngine.artistKey(song.artist)
            val lead = leadKey(song.artist)
            if (full != lead) {
                taste.artistWeights[lead]?.let { weights.putIfAbsent(full, it) }
            }
            if (full !in genres) {
                (taste.artistGenres[lead] ?: genresOf(song.artist) ?: genresOf(lead))
                    ?.let { genres[full] = it }
            }
        }
        return taste.copy(artistWeights = weights, artistGenres = genres)
    }

    /** The key the listening history uses for whoever leads a credit. */
    private fun leadKey(credit: String): String =
        AiMixEngine.artistKey(ListeningStats.primaryArtist(credit) ?: credit)

    private fun genresOf(artist: String): Set<String>? =
        ArtistFacts.genresFor(artist).map(AiMixGenres::keyOf).toSet().takeIf { it.isNotEmpty() }

    // ── Candidates ───────────────────────────────────────────────────────────

    /** The radio of a few of the listener's most played songs, a different few each time. */
    private suspend fun habitCandidates(songs: List<RankedSong>, random: Random): List<AiMixCandidate> {
        val ranked = songs.sortedByDescending { it.ms }
        val seeds = (
            ranked.take(SEED_POOL).shuffled(random).take(SEEDS_PER_MIX) +
                ranked.drop(SEED_POOL).take(30).shuffled(random).take(EXTRA_SEEDS)
            ).map { it.song }
        return radios(seeds, AiMixOrigin.HABIT_RADIO)
    }

    /**
     * Search hits for the genre, plus the radio of a couple of songs that fit
     * it: the listener's own where they have any, otherwise the top search hits.
     */
    private suspend fun genreCandidates(
        genre: AiMixGenre,
        history: List<RankedSong>,
        taste: AiMixTaste,
        random: Random,
    ): List<AiMixCandidate> = coroutineScope {
        val searches = genre.queries.map { query ->
            async { searchSongs(query) }
        }.awaitAll()

        val found = searches.flatMap { songs ->
            songs.mapIndexed { rank, song -> AiMixCandidate(song, AiMixOrigin.GENRE_SEARCH, rank) }
        }

        val key = AiMixGenres.keyOf(genre.id)
        val own = history
            .filter { key in taste.artistGenres[leadKey(it.song.artist)].orEmpty() }
            .sortedByDescending { it.ms }
            .take(4)
            .shuffled(random)
            .take(2)
            .map { it.song }
        val seeds = own.ifEmpty { searches.firstOrNull().orEmpty().take(2) }

        found + radios(seeds, AiMixOrigin.GENRE_RADIO)
    }

    private suspend fun searchSongs(query: String): List<Song> =
        YtMusicRepository.search(query, SearchFilter.SONGS).getOrNull().orEmpty().mapNotNull { row ->
            when (row) {
                is SearchResult.TopTrack -> row.song
                is SearchResult.Track -> row.song
                is SearchResult.Browse -> null
            }
        }

    private suspend fun radios(seeds: List<Song>, origin: AiMixOrigin): List<AiMixCandidate> = coroutineScope {
        seeds.map { seed ->
            async {
                val related = YtMusicRepository.radio(seed.videoId).getOrNull().orEmpty()
                // The seed comes back first in its own radio.
                related.filterNot { it.videoId == seed.videoId }
                    .mapIndexed { rank, song -> AiMixCandidate(song, origin, rank) }
            }
        }.awaitAll().flatten()
    }

    // ── Sound ────────────────────────────────────────────────────────────────

    /**
     * Tempo and key for the candidates Automix has already analysed, so the mix
     * can be ordered to flow. A candidate nobody has played has no entry, which
     * the engine treats as neutral: analysing a song means downloading it, and a
     * mix is not worth that.
     */
    private fun featuresFor(context: Context, ids: List<String>): Map<String, AiMixFeatures> {
        val analyses = store ?: AnalysisStore { context.filesDir }.also { store = it }
        val out = HashMap<String, AiMixFeatures>()
        for (id in ids) {
            val analysis = analyses.load(id)?.takeIf { it.isUsable } ?: continue
            out[id] = AiMixFeatures(bpm = analysis.bpm, key = analysis.key)
        }
        return out
    }
}
