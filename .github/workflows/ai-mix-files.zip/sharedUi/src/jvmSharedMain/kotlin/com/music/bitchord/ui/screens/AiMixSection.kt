package com.music.bitchord.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.music.bitchord.playback.smart.AiMixGenres
import com.music.bitchord.playback.smart.AiMixMode
import com.music.bitchord.sharedui.resources.*
import com.music.bitchord.ui.components.PAGE_GUTTER
import com.music.bitchord.ui.components.ShelfRow
import org.jetbrains.compose.resources.stringResource

/**
 * The Home feed's AI Mix section: pick what to mix from — the listener's own
 * habits, any genre the AI picks at random, or one genre by hand — and start it.
 *
 * Stateless about the mix itself. [busy] and [failed] come from whoever builds
 * it, and [onStart] is told which kind of mix was asked for. Only the chip
 * selection lives here, because nothing outside needs to know it until Start.
 */
@Composable
fun AiMixSection(
    busy: Boolean,
    failed: Boolean,
    onStart: (AiMixMode) -> Unit,
    modifier: Modifier = Modifier,
) {
    var selected by remember { mutableStateOf<AiMixMode>(AiMixMode.ForYou) }

    Column(modifier = modifier.fillMaxWidth()) {
        SectionHeader(
            title = stringResource(Res.string.ai_mix_title),
            subtitle = stringResource(Res.string.ai_mix_subtitle),
        )

        ShelfRow(
            contentPadding = PaddingValues(horizontal = PAGE_GUTTER),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item(key = "ai-mix-for-you") {
                MixChip(
                    label = stringResource(Res.string.ai_mix_for_you),
                    selected = selected is AiMixMode.ForYou,
                    onClick = { selected = AiMixMode.ForYou },
                )
            }
            item(key = "ai-mix-surprise") {
                MixChip(
                    label = stringResource(Res.string.ai_mix_surprise),
                    selected = selected is AiMixMode.Surprise,
                    onClick = { selected = AiMixMode.Surprise },
                )
            }
            items(AiMixGenres.ALL, key = { "ai-mix-genre-${it.id}" }) { genre ->
                MixChip(
                    label = genre.label,
                    selected = (selected as? AiMixMode.Genre)?.id == genre.id,
                    onClick = { selected = AiMixMode.Genre(genre.id) },
                )
            }
        }

        val description = when (val mode = selected) {
            is AiMixMode.ForYou -> stringResource(Res.string.ai_mix_desc_for_you)
            is AiMixMode.Surprise -> stringResource(Res.string.ai_mix_desc_surprise)
            is AiMixMode.Genre -> stringResource(
                Res.string.ai_mix_desc_genre,
                AiMixGenres.byId(mode.id)?.label ?: mode.id,
            )
        }

        Box(
            modifier = Modifier
                .padding(horizontal = PAGE_GUTTER, vertical = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.tertiaryContainer,
                        ),
                    ),
                ),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable(enabled = !busy) { onStart(selected) }
                            .padding(horizontal = 22.dp, vertical = 10.dp),
                    ) {
                        Text(
                            text = stringResource(
                                if (busy) Res.string.ai_mix_busy else Res.string.ai_mix_start,
                            ),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                    }
                    if (busy) {
                        Spacer(Modifier.width(12.dp))
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                }
                if (failed && !busy) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = stringResource(Res.string.ai_mix_failed),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }
    }
}

/** A selectable pill. Drawn by hand, like the rest of the Home feed's controls. */
@Composable
private fun MixChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val container = if (selected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val content = if (selected) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(container)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = content,
            maxLines = 1,
        )
    }
}
