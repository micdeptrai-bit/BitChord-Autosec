package com.music.bitchord.playback.smart

import com.music.bitchord.data.model.Song
import kotlin.random.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class AiMixEngineTest {

    private fun song(id: String, artist: String, title: String = "title $id") =
        Song(videoId = id, title = title, artist = artist, thumbnailUrl = null)

    private fun cand(
        id: String,
        artist: String,
        origin: AiMixOrigin = AiMixOrigin.HABIT_RADIO,
        rank: Int = 0,
    ) = AiMixCandidate(song(id, artist), origin, rank)

    private fun build(
        candidates: List<AiMixCandidate>,
        mode: AiMixMode = AiMixMode.ForYou,
        taste: AiMixTaste = AiMixTaste(),
        size: Int = 30,
        freshShare: Double = 1.0,
        features: Map<String, AiMixFeatures> = emptyMap(),
    ): List<Song> = AiMixEngine.build(
        mode = mode,
        taste = taste,
        candidates = candidates,
        size = size,
        freshShare = freshShare,
        features = features,
        random = Random(42),
    )

    @Test
    fun emptyCandidatesGiveAnEmptyMix() {
        assertTrue(build(emptyList()).isEmpty())
    }

    @Test
    fun theMixNeverExceedsTheRequestedSize() {
        val candidates = (1..40).map { cand("v$it", "artist $it") }
        assertEquals(10, build(candidates, size = 10).size)
    }

    @Test
    fun theSameSongIsNotQueuedTwice() {
        val candidates = listOf(
            // Same video id.
            AiMixCandidate(song("a", "X", title = "One"), AiMixOrigin.HABIT_RADIO),
            AiMixCandidate(song("a", "X", title = "Other"), AiMixOrigin.HABIT_RADIO),
            // Different id, same title and artist: a re-upload.
            AiMixCandidate(song("b", "X", title = "One"), AiMixOrigin.GENRE_SEARCH),
        )
        assertEquals(1, build(candidates).size)
    }

    @Test
    fun anArtistGetsAtMostTwoSlots() {
        val candidates = (1..6).map { cand("a$it", "Artist A") } +
            (1..2).map { cand("b$it", "Artist B") }
        val mix = build(candidates, size = 10)
        assertEquals(2, mix.count { it.artist == "Artist A" })
        assertEquals(4, mix.size)
    }

    @Test
    fun sameArtistIsNotPlayedBackToBackWhenItCanBeAvoided() {
        val candidates = listOf(
            cand("a1", "A"), cand("a2", "A"),
            cand("b1", "B"), cand("b2", "B"),
            cand("c1", "C"), cand("c2", "C"),
        )
        val mix = build(candidates, size = 6)
        assertEquals(6, mix.size)
        for (i in 1 until mix.size) {
            assertNotEquals(mix[i - 1].artist, mix[i].artist, "positions ${i - 1} and $i")
        }
    }

    @Test
    fun aGenreMixPrefersArtistsKnownForThatGenre() {
        val taste = AiMixTaste(
            artistGenres = mapOf(
                AiMixEngine.artistKey("Jazz One") to setOf("jazz"),
                AiMixEngine.artistKey("Jazz Two") to setOf("jazz"),
                AiMixEngine.artistKey("Jazz Three") to setOf("jazz"),
                AiMixEngine.artistKey("Rock One") to setOf("rock"),
                AiMixEngine.artistKey("Rock Two") to setOf("rock"),
                AiMixEngine.artistKey("Rock Three") to setOf("rock"),
            ),
        )
        val candidates = listOf(
            cand("r1", "Rock One"), cand("r2", "Rock Two"), cand("r3", "Rock Three"),
            cand("j1", "Jazz One"), cand("j2", "Jazz Two"), cand("j3", "Jazz Three"),
        )
        val mix = build(candidates, mode = AiMixMode.Genre("jazz"), taste = taste, size = 3)
        assertEquals(setOf("j1", "j2", "j3"), mix.map { it.videoId }.toSet())
    }

    @Test
    fun anArtistTheListenerPlaysOutranksAStranger() {
        val taste = AiMixTaste(artistWeights = mapOf(AiMixEngine.artistKey("Loved") to 1.0))
        val candidates = listOf(cand("s", "Stranger"), cand("l", "Loved"))
        val mix = build(candidates, taste = taste, size = 1)
        assertEquals("l", mix.single().videoId)
    }

    @Test
    fun familiarSongsAreMixedInButDoNotLeadTheMix() {
        val familiarIds = (1..4).map { "f$it" }
        val taste = AiMixTaste(songPlays = familiarIds.associateWith { 5 })
        val candidates = familiarIds.mapIndexed { i, id -> cand(id, "Known $i") } +
            (1..8).map { cand("n$it", "New $it") }
        val mix = build(candidates, taste = taste, size = 10, freshShare = 0.6)
        assertEquals(10, mix.size)
        assertEquals(4, mix.count { it.videoId in familiarIds })
        assertFalse(mix.first().videoId in familiarIds)
    }

    @Test
    fun whenThereAreNotEnoughNewSongsFamiliarOnesFillIn() {
        val familiarIds = (1..8).map { "f$it" }
        val taste = AiMixTaste(songPlays = familiarIds.associateWith { 3 })
        val candidates = familiarIds.mapIndexed { i, id -> cand(id, "Known $i") } +
            (1..2).map { cand("n$it", "New $it") }
        val mix = build(candidates, taste = taste, size = 6, freshShare = 0.6)
        assertEquals(6, mix.size)
    }

    @Test
    fun arrangementAvoidsAJumpToAClashingKeyAndTempo() {
        // s1 is the strongest candidate so it always opens the mix.
        val candidates = listOf(
            cand("s1", "A", AiMixOrigin.HABIT_RADIO),
            cand("s2", "B", AiMixOrigin.GENRE_SEARCH),
            cand("s3", "C", AiMixOrigin.GENRE_SEARCH),
            cand("s4", "D", AiMixOrigin.GENRE_SEARCH),
        )
        val features = mapOf(
            "s1" to AiMixFeatures(bpm = 120.0, key = "8A"),
            "s2" to AiMixFeatures(bpm = 150.0, key = "3B"),
            "s3" to AiMixFeatures(bpm = 120.0, key = "8A"),
            "s4" to AiMixFeatures(bpm = 122.0, key = "9A"),
        )
        val mix = build(candidates, size = 4, features = features)
        assertEquals("s1", mix.first().videoId)
        assertNotEquals("s2", mix[1].videoId)
    }

    @Test
    fun transitionCostPrefersSameKeyAndTempo() {
        val base = AiMixFeatures(120.0, "8A")
        assertEquals(0.0, AiMixEngine.transitionCost(base, base))
        assertTrue(
            AiMixEngine.transitionCost(base, AiMixFeatures(120.0, "9A")) <
                AiMixEngine.transitionCost(base, AiMixFeatures(120.0, "3B")),
        )
    }

    @Test
    fun analyzerKeyNamesAreUnderstood() {
        // A minor and C major are relative keys: the same slot on the wheel.
        val minor = AiMixFeatures(120.0, "A minor")
        val relativeMajor = AiMixFeatures(120.0, "C major")
        assertEquals(0.1, AiMixEngine.transitionCost(minor, relativeMajor))
        // And the same song's key written both ways is the same key.
        assertEquals(
            0.0,
            AiMixEngine.transitionCost(minor, AiMixFeatures(120.0, "8A")),
        )
        // A fifth up in the same mode is one step round the wheel.
        assertEquals(
            0.1,
            AiMixEngine.transitionCost(AiMixFeatures(120.0, "C major"), AiMixFeatures(120.0, "G major")),
        )
    }

    @Test
    fun anUnreadableKeyIsNeutralNotAnError() {
        val known = AiMixFeatures(120.0, "8A")
        val unknown = AiMixFeatures(120.0, "")
        assertEquals(0.3, AiMixEngine.transitionCost(known, unknown))
    }

    @Test
    fun halfTimeCountsAsTheSamePulse() {
        assertEquals(
            0.0,
            AiMixEngine.transitionCost(AiMixFeatures(120.0, "8A"), AiMixFeatures(60.0, "8A")),
        )
    }

    @Test
    fun unknownSoundIsNeutral() {
        assertEquals(0.5, AiMixEngine.transitionCost(null, AiMixFeatures(120.0, "8A")))
        assertEquals(0.5, AiMixEngine.transitionCost(AiMixFeatures(120.0, "8A"), null))
    }

    @Test
    fun surpriseNeverRepeatsTheExcludedGenre() {
        val random = Random(1)
        repeat(60) {
            assertNotEquals("jazz", AiMixGenres.pickSurprise(random, except = "jazz").id)
        }
    }

    @Test
    fun genreSpellingsAreNormalised() {
        assertEquals("hiphop", AiMixGenres.keyOf("Hip Hop"))
        assertEquals("rnb", AiMixGenres.keyOf("R&B"))
        assertEquals("kpop", AiMixGenres.keyOf("K Pop"))
        assertEquals("lofi", AiMixGenres.keyOf("Lo-Fi"))
    }

    @Test
    fun everyPickableGenreIsAlreadyInItsNormalForm() {
        AiMixGenres.ALL.forEach { genre ->
            assertEquals(genre.id, AiMixGenres.keyOf(genre.id), genre.label)
        }
    }
}
