package com.music.bitchord.playback.smart

import com.music.bitchord.data.model.Song
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * A genre the listener can pick for an AI Mix.
 *
 * [id] is already normalised (see [AiMixGenres.keyOf]) so it can be compared
 * with the genres [com.music.bitchord.data.stats.ArtistFacts] reports without
 * caring how either side spells "hip-hop". [label] is what the chip shows.
 * [queries] are what is typed into YouTube Music search to find the genre's
 * songs; they are tried in order and each contributes candidates.
 */
data class AiMixGenre(
    val id: String,
    val label: String,
    val queries: List<String> = listOf("$label hits", "best $label songs"),
)

/** What an AI Mix is built around. */
sealed interface AiMixMode {
    /** Built from what the listener plays. */
    data object ForYou : AiMixMode

    /** A genre the listener picked by hand. */
    data class Genre(val id: String) : AiMixMode

    /** A genre the engine picks at random. Resolved to [Genre] before building. */
    data object Surprise : AiMixMode
}

object AiMixGenres {
    val ALL: List<AiMixGenre> = listOf(
        AiMixGenre("pop", "Pop"),
        AiMixGenre("vpop", "V-Pop", listOf("nhạc Việt hay nhất", "V-Pop hits")),
        AiMixGenre("kpop", "K-Pop"),
        AiMixGenre("jpop", "J-Pop"),
        AiMixGenre("rock", "Rock"),
        AiMixGenre("hiphop", "Hip Hop"),
        AiMixGenre("rnb", "R&B"),
        AiMixGenre("edm", "EDM", listOf("EDM hits", "best electronic dance songs")),
        AiMixGenre("house", "House"),
        AiMixGenre("lofi", "Lo-fi", listOf("lofi chill beats", "lo-fi hip hop songs")),
        AiMixGenre("jazz", "Jazz"),
        AiMixGenre("blues", "Blues"),
        AiMixGenre("soul", "Soul"),
        AiMixGenre("funk", "Funk"),
        AiMixGenre("disco", "Disco"),
        AiMixGenre("country", "Country"),
        AiMixGenre("indie", "Indie"),
        AiMixGenre("latin", "Latin"),
        AiMixGenre("reggae", "Reggae"),
        AiMixGenre("metal", "Metal"),
        AiMixGenre("classical", "Classical", listOf("classical music masterpieces", "best classical pieces")),
        AiMixGenre("acoustic", "Acoustic"),
        AiMixGenre("ballad", "Ballad"),
    )

    fun byId(id: String): AiMixGenre? = ALL.firstOrNull { it.id == id }

    /**
     * A genre name from anywhere (Last.fm tag, ArtistFacts label, a chip),
     * reduced to the form [AiMixGenre.id] uses.
     */
    fun keyOf(name: String): String {
        val flat = name.lowercase().filter { it.isLetterOrDigit() }
        return KEY_ALIASES[flat] ?: flat
    }

    /**
     * Any genre at all, for "surprise me". Never [except] — the one the last
     * Surprise used — so pressing it twice does not repeat itself. When the
     * list has nothing else to offer the exclusion is ignored.
     */
    fun pickSurprise(random: Random, except: String? = null): AiMixGenre {
        val pool = ALL.filter { it.id != except }.ifEmpty { ALL }
        return pool[random.nextInt(pool.size)]
    }

    private val KEY_ALIASES = mapOf(
        "rb" to "rnb",
        "randb" to "rnb",
        "rhythmandblues" to "rnb",
        "hiphoprap" to "hiphop",
        "rap" to "hiphop",
        "lo" to "lofi",
        "lofihiphop" to "lofi",
        "chillhop" to "lofi",
        "electronic" to "edm",
        "vietnamese" to "vpop",
    )
}

/**
 * What the listener's own history says, already boiled down.
 *
 * All keys are normalised with [AiMixEngine.artistKey] / [AiMixGenres.keyOf]
 * by whoever builds this, so the engine never has to guess at spelling.
 *
 * @property songPlays plays per video id. A song in here counts as familiar.
 * @property artistWeights how much the listener plays each artist, scaled so the
 *   most played is 1.0.
 * @property artistGenres the genres known for an artist. Empty for an artist
 *   nothing is known about, which is the usual case when genre lookups are off.
 */
data class AiMixTaste(
    val songPlays: Map<String, Int> = emptyMap(),
    val artistWeights: Map<String, Double> = emptyMap(),
    val artistGenres: Map<String, Set<String>> = emptyMap(),
)

/** How a candidate was found. A related track of something loved beats a cold search hit. */
enum class AiMixOrigin(val base: Double) {
    /** On YouTube Music's radio for a song the listener plays a lot. */
    HABIT_RADIO(1.0),

    /** On the radio of a song that fits the chosen genre. */
    GENRE_RADIO(0.9),

    /** A search hit for the chosen genre. */
    GENRE_SEARCH(0.8),
}

/**
 * One song that might go into the mix.
 *
 * @property rank where it stood in the list it came from, 0 being first. Both
 *   radio and search put their best guesses first, so earlier is worth a little.
 */
data class AiMixCandidate(
    val song: Song,
    val origin: AiMixOrigin,
    val rank: Int = 0,
)

/** What is known about a track's sound, from Automix's analysis cache. */
data class AiMixFeatures(
    val bpm: Double,
    /**
     * The key as [TrackAnalysis.key] states it, a pitch name and a mode such as
     * `C♯ minor`. A Camelot code (`8A`) is accepted as well. Anything else is
     * treated as unknown.
     */
    val key: String,
)

/**
 * Turns a pile of candidates into an ordered queue.
 *
 * Pure on purpose: no network, no storage, no clock. The caller gathers the
 * candidates and the taste; this decides what is worth playing and in what
 * order, which is the part that needs tests.
 *
 * ## The idea
 *
 *  1. **Score** each candidate: where it came from, whether the listener plays
 *     that artist, and — for a genre mix — whether the artist is known to fit.
 *  2. **Split** into songs the listener knows and songs they don't, and take
 *     mostly new ones ([freshShare]); a mix that only replays favourites is a
 *     playlist, and one that is all strangers is a gamble.
 *  3. **Weave** the two groups so the familiar ones are spread out rather than
 *     bunched at the start.
 *  4. **Arrange**: walk the list, and at each step take, from the next few
 *     songs, the one that follows the current one best by tempo and key. That
 *     only reorders locally, so the weave survives. Songs with no analysis are
 *     neutral and keep their place. Automix does the actual blending on
 *     playback.
 */
object AiMixEngine {

    const val DEFAULT_SIZE = 30
    private const val MAX_PER_ARTIST = 2
    private const val ARRANGE_WINDOW = 6

    /** An artist's name as every map in [AiMixTaste] is keyed. */
    fun artistKey(name: String): String = name.lowercase().filter { it.isLetterOrDigit() }

    /**
     * @param mode [AiMixMode.ForYou] or [AiMixMode.Genre]. [AiMixMode.Surprise]
     *   has no genre yet and is treated as ForYou; resolve it first with
     *   [AiMixGenres.pickSurprise].
     * @param freshShare the share of the mix that should be songs the listener
     *   has not played, 0.0–1.0.
     */
    fun build(
        mode: AiMixMode,
        taste: AiMixTaste,
        candidates: List<AiMixCandidate>,
        size: Int = DEFAULT_SIZE,
        freshShare: Double = 0.6,
        features: Map<String, AiMixFeatures> = emptyMap(),
        random: Random = Random.Default,
    ): List<Song> {
        if (size <= 0) return emptyList()
        val genreKey = (mode as? AiMixMode.Genre)?.id?.let(AiMixGenres::keyOf)

        val scored = dedupe(candidates).map { candidate ->
            Scored(candidate.song, score(candidate, taste, genreKey, random), isFamiliar(candidate.song, taste))
        }
        if (scored.isEmpty()) return emptyList()

        val fresh = scored.filterNot { it.familiar }.sortedByDescending { it.score }
        val familiar = scored.filter { it.familiar }.sortedByDescending { it.score }

        val freshWanted = (size * freshShare.coerceIn(0.0, 1.0)).roundToInt()
        val artistCount = HashMap<String, Int>()
        val pickedFresh = pick(fresh, freshWanted, artistCount)
        val pickedFamiliar = pick(familiar, size - pickedFresh.size, artistCount)
        // One group ran dry: let the other make up the difference.
        val shortBy = size - pickedFresh.size - pickedFamiliar.size
        val extraFresh = if (shortBy > 0) {
            pick(fresh.filterNot { it in pickedFresh }, shortBy, artistCount)
        } else {
            emptyList()
        }
        val freshAll = pickedFresh + extraFresh
        val stillShort = size - freshAll.size - pickedFamiliar.size
        val extraFamiliar = if (stillShort > 0) {
            pick(familiar.filterNot { it in pickedFamiliar }, stillShort, artistCount)
        } else {
            emptyList()
        }

        val woven = weave(freshAll, pickedFamiliar + extraFamiliar)
        return separateNeighbours(arrange(woven, features)).map { it.song }
    }

    // ── Scoring ──────────────────────────────────────────────────────────────

    private class Scored(val song: Song, val score: Double, val familiar: Boolean)

    private fun score(
        candidate: AiMixCandidate,
        taste: AiMixTaste,
        genreKey: String?,
        random: Random,
    ): Double {
        val song = candidate.song
        val artist = artistKey(song.artist)
        var total = candidate.origin.base
        total += 0.3 / (1.0 + candidate.rank / 5.0)
        total += 0.8 * (taste.artistWeights[artist] ?: 0.0)
        if (genreKey != null) {
            val known = taste.artistGenres[artist].orEmpty()
            if (genreKey in known) {
                total += 0.6
            } else if (known.isNotEmpty()) {
                // Known, and known to be something else.
                total -= 0.4
            }
        }
        if (song.isVideo) total -= 0.25
        // A little noise so two mixes from the same history are not identical.
        total += random.nextDouble() * 0.15
        return total
    }

    private fun isFamiliar(song: Song, taste: AiMixTaste): Boolean =
        (taste.songPlays[song.videoId] ?: 0) > 0

    private fun dedupe(candidates: List<AiMixCandidate>): List<AiMixCandidate> {
        val seenIds = HashSet<String>()
        val seenNames = HashSet<String>()
        return candidates.filter { candidate ->
            val song = candidate.song
            if (song.videoId.isBlank()) return@filter false
            val name = artistKey(song.title) + "|" + artistKey(song.artist)
            // `add` is false for a repeat; both sets must see the song.
            val newId = seenIds.add(song.videoId)
            val newName = seenNames.add(name)
            newId && newName
        }
    }

    /** The best [count] of [sorted], at most [MAX_PER_ARTIST] per artist across the whole mix. */
    private fun pick(sorted: List<Scored>, count: Int, artistCount: MutableMap<String, Int>): List<Scored> {
        if (count <= 0) return emptyList()
        val out = ArrayList<Scored>(count)
        for (item in sorted) {
            if (out.size >= count) break
            val artist = artistKey(item.song.artist)
            val used = artistCount[artist] ?: 0
            if (used >= MAX_PER_ARTIST) continue
            artistCount[artist] = used + 1
            out += item
        }
        return out
    }

    /** Familiar songs spread evenly through the new ones. */
    private fun weave(fresh: List<Scored>, familiar: List<Scored>): List<Scored> {
        val total = fresh.size + familiar.size
        if (familiar.isEmpty()) return fresh
        if (fresh.isEmpty()) return familiar
        val familiarShare = familiar.size.toDouble() / total
        val out = ArrayList<Scored>(total)
        var f = 0
        var k = 0
        while (f < fresh.size || k < familiar.size) {
            val want = familiarShare * (out.size + 1)
            val takeFamiliar = k < familiar.size && (f >= fresh.size || k < want - 0.5)
            if (takeFamiliar) out += familiar[k++] else out += fresh[f++]
        }
        return out
    }

    // ── Ordering ─────────────────────────────────────────────────────────────

    private fun arrange(order: List<Scored>, features: Map<String, AiMixFeatures>): List<Scored> {
        if (order.size < 2) return order
        val remaining = order.toMutableList()
        val out = ArrayList<Scored>(order.size)
        out += remaining.removeAt(0)
        while (remaining.isNotEmpty()) {
            val last = out.last()
            val window = min(ARRANGE_WINDOW, remaining.size)
            var best = 0
            var bestCost = Double.MAX_VALUE
            for (i in 0 until window) {
                val next = remaining[i]
                var cost = transitionCost(features[last.song.videoId], features[next.song.videoId])
                cost += 0.05 * i
                if (artistKey(next.song.artist) == artistKey(last.song.artist)) cost += 1.0
                if (cost < bestCost) {
                    bestCost = cost
                    best = i
                }
            }
            out += remaining.removeAt(best)
        }
        return out
    }

    /**
     * The walk in [arrange] can paint itself into a corner and end on two songs
     * by the same artist, because the last ones left are all that is available.
     * Swap such a song with one elsewhere in the list, but only when the swap
     * leaves neither place next to the same artist, so it never trades one
     * clash for another.
     */
    private fun separateNeighbours(order: List<Scored>): List<Scored> {
        val list = order.toMutableList()
        fun same(a: Int, b: Int): Boolean =
            a in list.indices && b in list.indices &&
                artistKey(list[a].song.artist) == artistKey(list[b].song.artist)
        fun clashes(i: Int): Boolean = same(i, i - 1) || same(i, i + 1)

        for (i in 1 until list.size) {
            if (!same(i, i - 1)) continue
            val others = (i + 1 until list.size) + (0 until i - 1)
            for (j in others) {
                val moved = list[i]
                list[i] = list[j]
                list[j] = moved
                if (!clashes(i) && !clashes(j)) break
                list[j] = list[i]
                list[i] = moved
            }
        }
        return list
    }

    /**
     * How awkward it is to go from [from] to [to]. Lower is better. Unknown
     * sound is neutral (0.5) rather than good or bad, so unanalysed songs stay
     * where the weave put them.
     */
    fun transitionCost(from: AiMixFeatures?, to: AiMixFeatures?): Double {
        if (from == null || to == null) return NEUTRAL_COST
        return tempoCost(from.bpm, to.bpm) + keyCost(from.key, to.key)
    }

    private const val NEUTRAL_COST = 0.5

    /** Tempo gap, with half and double time counted as the same pulse. */
    private fun tempoCost(a: Double, b: Double): Double {
        if (a <= 0.0 || b <= 0.0) return 0.3
        var ratio = max(a, b) / min(a, b)
        while (ratio >= 1.5) ratio /= 2.0
        return abs(ratio - 1.0) * 4.0
    }

    /** Distance on the Camelot wheel: same key is free, neighbours are cheap. */
    private fun keyCost(a: String, b: String): Double {
        val x = parseKey(a) ?: return 0.3
        val y = parseKey(b) ?: return 0.3
        val gap = abs(x.first - y.first)
        val around = min(gap, 12 - gap)
        val sameMode = x.second == y.second
        return if (sameMode) {
            when (around) {
                0 -> 0.0
                1 -> 0.1
                else -> 0.2 + 0.05 * around
            }
        } else {
            when (around) {
                0 -> 0.1
                1 -> 0.4
                else -> 0.4 + 0.05 * around
            }
        }
    }

    private val PITCH = mapOf(
        "C" to 0, "C♯" to 1, "C#" to 1, "D♭" to 1, "DB" to 1, "D" to 2,
        "D♯" to 3, "D#" to 3, "E♭" to 3, "EB" to 3, "E" to 4, "F" to 5,
        "F♯" to 6, "F#" to 6, "G♭" to 6, "GB" to 6, "G" to 7,
        "G♯" to 8, "G#" to 8, "A♭" to 8, "AB" to 8, "A" to 9,
        "A♯" to 10, "A#" to 10, "B♭" to 10, "BB" to 10, "B" to 11,
    )

    /**
     * A key as a position on the Camelot wheel: its number 1–12 and `'A'`
     * (minor) or `'B'` (major). Takes either a Camelot code or the analyzer's
     * `C♯ minor`. A pitch with no stated mode is read as major.
     */
    private fun parseKey(code: String): Pair<Int, Char>? {
        val trimmed = code.trim().uppercase()
        if (trimmed.isEmpty()) return null

        // Already Camelot: `8A`.
        val last = trimmed.last()
        if ((last == 'A' || last == 'B') && trimmed.length >= 2) {
            val number = trimmed.dropLast(1).toIntOrNull()
            if (number != null) return if (number in 1..12) number to last else null
        }

        val parts = trimmed.split(' ').filter { it.isNotEmpty() }
        val pitch = PITCH[parts.firstOrNull()] ?: return null
        val minor = parts.getOrNull(1)?.startsWith("MIN") == true
        // Minor keys sit on the wheel as their relative major, three semitones up.
        val majorPitch = if (minor) (pitch + 3) % 12 else pitch
        val number = ((7 + majorPitch * 7) % 12) + 1
        return number to (if (minor) 'A' else 'B')
    }
}
